//
//  TabBar.swift
//  CornellCarpool
//
//  Created by Richard Gu on 1/4/22.
//

import SwiftUI

struct TabBar: View {
    var body: some View {
        TabView {
            ContentView()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            DestinationsView()
                .tabItem {
                    Image(systemName: "car")
                    Text("Destinations")
                }
            AccountView()
                .tabItem {
                    Image(systemName: "person.crop.circle")
                    Text("Settings")
                }
        }
    }
}

struct TabBar_Previews: PreviewProvider {
    static var previews: some View {
        TabBar()
    }
}
