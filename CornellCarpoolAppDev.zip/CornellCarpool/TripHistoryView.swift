//
//  TripHistoryView.swift
//  CornellCarpool
//
//  Created by Richard Gu on 1/7/22.
//

import SwiftUI

struct TripHistoryView: View {
    var body: some View {
        NavigationView {
            VStack {
                    List {
                        VStack(alignment: .leading, spacing: 8.0) {
                            Text("Spring 2022")
                                .font(.title2)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            List {
                                ScrollView (.vertical, showsIndicators: false) {
                                }
                            }
                            
                        }
                        .listStyle(.insetGrouped)
                    }
                    List {
                        VStack(alignment: .leading, spacing: 8.0) {
                            Text("Fall 2021")
                                .font(.title2)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            ScrollView (.vertical, showsIndicators: false) {
                            }
                            
                        }
                        .listStyle(.insetGrouped)
                    }
                    List {
                        VStack(alignment: .leading, spacing: 8.0) {
                            Text("Spring 2021")
                                .font(.title2)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            ScrollView (.vertical, showsIndicators: false) {
                            }
                            
                        }
                        .listStyle(.insetGrouped)
                    }
                
            }
            .navigationTitle("Trip History")
        }
    }
}

struct TripHistoryView_Previews: PreviewProvider {
    static var previews: some View {
        TripHistoryView()
    }
}
