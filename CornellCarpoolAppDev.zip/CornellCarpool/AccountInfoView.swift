//
//  AccountInfoView.swift
//  CornellCarpool
//
//  Created by Richard Gu on 1/7/22.
//

import SwiftUI

struct AccountInfoView: View {
    var body: some View {
        NavigationView {
            VStack {
                    List {
                        VStack(alignment: .leading, spacing: 8.0) {
                            Text("Richard Gu")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            Text("Username")
                                .font(.title2)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            Text("rg779")
                                .font(.caption)
                                .foregroundColor(.primary)
                                .lineLimit(1)
                            Text("Email")
                                .font(.title2)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            Text("richardgu0114@gmail.com")
                                .font(.caption)
                                .foregroundColor(.primary)
                                .lineLimit(1)
                            Text("Year")
                                .font(.title2)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            Text("Freshman")
                                .font(.caption)
                                .foregroundColor(.primary)
                                .lineLimit(1)
                            Text("College")
                                .font(.title2)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            Text("Arts & Sciences")
                                .font(.caption)
                                .foregroundColor(.primary)
                                .lineLimit(1)
                        }
                        .listStyle(.insetGrouped)
                    }
                    List {
                        VStack(alignment: .leading, spacing: 8.0) {
                            Text("Total Number of Trips")
                                .font(.title2)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            Text("4")
                                .font(.caption)
                                .foregroundColor(.primary)
                                .lineLimit(1)
                            Text("Favorite Destination")
                                .font(.title2)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            Text("San Francisco")
                                .font(.caption)
                                .foregroundColor(.primary)
                                .lineLimit(1)
                            Text("Member since")
                                .font(.title2)
                                .fontWeight(.bold)
                                .lineLimit(1)
                            Text("2022")
                                .font(.caption)
                                .foregroundColor(.primary)
                                .lineLimit(1)
                        }
                    }
            }
            .navigationTitle("Account Details")
        }
    }
}

struct AccountInfoView_Previews: PreviewProvider {
    static var previews: some View {
        AccountInfoView()
    }
}
