//
//  Destinations.swift
//  CornellCarpool
//
//  Created by Richard Gu on 1/4/22.
//

import SwiftUI

struct Destinations: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Destinations_Previews: PreviewProvider {
    static var previews: some View {
        Destinations()
    }
}
