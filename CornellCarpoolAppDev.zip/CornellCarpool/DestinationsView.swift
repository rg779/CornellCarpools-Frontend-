//
//  DestinationsView.swift
//  CornellCarpool
//
//  Created by Richard Gu on 1/4/22.
//

import SwiftUI

struct DestinationsView: View {
    var body: some View {
            VStack(alignment: .leading, spacing: 55) {
            NavigationView {
                List {
                    ScrollView (.vertical, showsIndicators: true) {
                        VStack(spacing: 8) {
                            NavigationLink(destination: NewTripView()) {
                                Image("nyc-wide")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 80)
                            }
                            NavigationLink(destination: NewTripView()) {
                                Image("boston-wide")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 80)
                            }
                            NavigationLink(destination: NewTripView()) {
                                Image("dc-wide")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 80)
                            }
                            NavigationLink(destination: NewTripView()) {
                                Image("houston-wide")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 80)
                            }
                            NavigationLink(destination: NewTripView()) {
                                Image("richmond-wide")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 80)
                            }
                        }
                    }
                    Text("Can't find what\nyou're looking for?")
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                        .lineLimit(2)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .foregroundColor(.primary)
                    NavigationLink(destination: DestinationsView2()) {
                        HStack {
                            Spacer()
                            Image("add-button")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(height: 40, alignment: .center)
                                
                            Spacer()
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .navigationTitle("Popular")
            }
        }
    }
}

struct DestinationsView_Previews: PreviewProvider {
    static var previews: some View {
        DestinationsView()
    }
}
