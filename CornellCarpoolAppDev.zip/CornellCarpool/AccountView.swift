//
//  AccountView.swift
//  CornellCarpool
//
//  Created by Richard Gu on 1/4/22.
//

import SwiftUI

struct AccountView: View {
    
    var body: some View {
        NavigationView {
            List {
                VStack(spacing: 8) {
                    Image(systemName: "person.crop.circle.fill.badge.checkmark")
                        .symbolVariant(.circle.fill)
                        .font(.system(size: 32))
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(.blue, .blue.opacity(0.3))
                        .padding()
                        .background(Circle().fill(.ultraThinMaterial))
                        
                    Text("Richard Gu")
                        .font(.title.weight(.semibold))
                    
                }
                .frame(maxWidth: .infinity)
                .padding()
                
                Section {
                    NavigationLink(destination: AccountInfoView()) {
                        Label("Account Info", systemImage: "info.circle.fill")
                    }
                    NavigationLink(destination: ContentView()) {
                        Label("Your Trip Groups", systemImage: "person.3.sequence")
                    }
                    NavigationLink(destination: ContentView()) {
                        Label("Saved", systemImage: "square.and.arrow.down")
                    }
                    
                    NavigationLink(destination: TripHistoryView()) {
                        Label("Trip History", systemImage: "clock")
                    }
                }
                .accentColor(.primary)
                .listRowSeparatorTint(.blue)
                Section {
                    NavigationLink(destination: ContentView()) {
                        Label("Settings", systemImage: "gear")
                    }
                    NavigationLink { Text("Billing") } label: {
                        Label("Billing", systemImage: "creditcard")
                    }
                    NavigationLink { ContentView() } label: {
                        Label("Help", systemImage: "questionmark")
                    }
                }
                .accentColor(.primary)
                .listRowSeparatorTint(.blue)
                .listRowSeparator(.hidden)
                
                Section {
                    Link(destination: URL(string: "https://google.com")!) {
                        HStack {
                            Label("Cornell Carpool Website", systemImage: "house")
                            Spacer()
                            Image(systemName: "link")
                                .foregroundColor(.secondary)
                            }
                        
                    }
                    
                }
                .accentColor(.primary)
                .listRowSeparator(.hidden)
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Account")
        }
    }
}

struct AccountView_Previews: PreviewProvider {
    static var previews: some View {
        AccountView()
    }
}
