//
//  DestinationsView2.swift
//  CornellCarpool
//
//  Created by Richard Gu on 1/7/22.
//

import SwiftUI

struct Destination: Identifiable {
    var id = UUID()
    let name: String
}

class DestinationsViewModel: ObservableObject {
    @Published var destinations: [Destination] = [
        Destination(name: "NYC"),
        Destination(name: "Boston"),
        Destination(name: "DC"),
        Destination(name: "Houston"),
        Destination(name: "Richmond")
    ]
}

struct DestinationsView2: View {
    @StateObject var viewModel = DestinationsViewModel()
    @State var text = ""

    var body: some View {
        NavigationView {
            VStack {
                Section(header: Text("Add New Destination")) {
                    TextField("Destination Name...", text: $text)
                        .padding()
                    Button(action: {
                        self.addToList()
                    }, label: {
                        Text("Add To List")
                            .bold()
                            .frame(width: 250, height: 50, alignment: .center)
                            .background(Color.green)
                            .cornerRadius(8)
                            .foregroundColor(Color.white)
                    })
                }

                List {
                    ForEach(viewModel.destinations) { destination in
                        DestinationRow(name: destination.name)
                    }
                }
            }
            .navigationTitle("Destinations")
        }
    }

    func addToList() {
        guard !text.trimmingCharacters(in: .whitespaces).isEmpty else {
            return
        }

        let newDestination = Destination(name: text)
        viewModel.destinations.append(newDestination)
        text = ""
    }
}

struct DestinationRow: View {
    let name: String
    var body: some View {
        Label (
            title: { Text(name) },
            icon: { Image(systemName: "airplane") }
        )
    }
}

struct DestinationsView2_Previews: PreviewProvider {
    static var previews: some View {
        DestinationsView2()
    }
}
