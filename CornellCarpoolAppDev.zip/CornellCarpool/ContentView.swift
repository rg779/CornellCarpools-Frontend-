//
//  ContentView.swift
//  CornellCarpool
//
//  Created by Richard Gu on 1/4/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            NavigationView {
                HStack {
                    VStack(alignment: .leading, spacing: 8.0) {
                        Text("Where to?")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .lineLimit(1)
                        Text("Popular Destinations")
                            .font(.title2)
                            .fontWeight(.bold)
                            .lineLimit(1)
                        Section {
                            NavigationLink(destination: DestinationsView()) {
                                Label("View All Destinations", systemImage: "airplane")
                            }
                        }
                        List {
                            ScrollView (.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                Image("nyc")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 150)
                                Image("boston")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 150)
                                Image("houston")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 150)
                                Image("richmond")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 150)
                            }
                            }
                        }
                        
                            
                        Text("Recent Trips")
                            .font(.title2)
                            .fontWeight(.bold)
                            .lineLimit(1)
                        Section {
                            NavigationLink(destination: TripHistoryView()) {
                                Label("View Full Trip History", systemImage: "airplane")
                            }
                        }
                        NavigationView {
                            List {
                                ScrollView (.vertical, showsIndicators: true) {
                                    VStack(spacing: 8) {
                                        Image("recent1")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(height: 80)
                                        Image("recent2")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(height: 80)
                                        Image("recent3")
                                            .resizable()
                                            .aspectRatio(contentMode: .fit)
                                            .frame(height: 80)
                                        
                                    }
                                }
                            }
                            .listStyle(.insetGrouped)
                            .offset(y: -80)
                            
                        }
                        NavigationLink(destination: NewTripView()) {
                            HStack {
                                Spacer()
                                Image("add-button-white")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 40, alignment: .center)
                                    //.border(Color.orange, width: 2)
                                    .cornerRadius(10)
                                    .overlay(RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.orange, lineWidth: 2))
                                    .shadow(radius: 5)
                                    //.padding(20)
                                    .padding(.vertical, 15)
                                    
                            }

                        }
                        
                        
                       
                        
                    
                    }
                
                }
            }
            
        }
        .padding(.horizontal, 15)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
