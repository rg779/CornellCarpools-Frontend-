//
//  CornellCarpoolApp.swift
//  CornellCarpool
//
//  Created by Richard Gu on 1/4/22.
//

import SwiftUI

@main
struct CornellCarpoolApp: App {
    var body: some Scene {
        WindowGroup {
            //ContentView()
            TabBar()
        }
    }
}
